-- Create A Notification

<void> Notification.new(<table> data{
    <string> Text,
    <int> Duration, -- optional
    <Color3> Color, -- optional
})

-- Set Color

<void> Notification.setColor(<Color3> color)
